package com.stackroute.basics;

import java.util.Scanner;

public class RectanglePerimeter {
	public static void main(String[] args) {
       new RectanglePerimeter().getValues();
       
    }

    //get user input from console
    public void getValues() {
    	Scanner s=new Scanner(System.in);
    	//System.out.println("Enter length and breadth of the rectangle:");
    	System.out.println(perimeterCalculator(s.nextDouble(), s.nextDouble()));

    }

    //write logic to find perimeter of rectangle here
    public double perimeterCalculator(double length, double breadth) {
    	double perimeter=2*(length+breadth);
    	
        return perimeter;
    }
}
