package com.stackroute.streams;

import java.util.List;
import java.util.OptionalDouble;

public class AverageFinder {
    //write logic to find the average of given list of integers
    public String findAverage(List<Integer> input) {
    	if(input.isEmpty()) {
    		return "Give proper input not empty list";
    	}
    	else if(input==null) {
    		return "Give proper input not null";
    	}
   
    	else {
    		OptionalDouble avg=input.stream()
    				.mapToDouble(n->n).average();    		
    		return "Average of given list of integers is "+avg.getAsDouble();			
    	}
    }
}