## Problem Statement: Find the average of the given list of integers ##

**Given a list of integers, find the average of the given list using Streams**

**This exercise contains a class named AverageFinder with the following method:**

    +findAverage(List<Integer>) : String 
        -Should accept list of integers as input and return String
        -Should find the average of the given list of integers
        -Should return result like "Average of given list of integers is 20.0" as string
        -Should return "Give proper input not empty list" if given list is empty
        -Should return "Give proper input not null" if given list is null

## Example
    Sample Input:
    [10,20,30]
    
    Expected Output:   
    Average of given list of integers is 20.0
--------------------------------------------------------
    Sample Input:
    null
    
    Expected Output:
    Give proper input not null
--------------------------------------------------------
    Sample Input:
    []
    
    Expected Output:
    Give proper input not empty list
    
## Instructions
- Avoid printing unnecessary values other than expected output as given in sample
- Take care of whitespace/trailing whitespace
- Do not change the provided class/method names unless instructed
- Follow best practices while coding