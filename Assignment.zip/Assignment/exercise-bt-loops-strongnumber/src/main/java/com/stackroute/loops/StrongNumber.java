package com.stackroute.loops;
import java.util.Scanner;
public class StrongNumber
{
    public static void main(String[] args)
{
        new StrongNumber().inputAcceptor();
}
    //write logic to get inputs from user and send inputs to inputValidator
    public void inputAcceptor()
{
Scanner sc = new Scanner(System.in);
//System.out.print("Enter a number: ");
       int number = sc.nextInt();
inputValidator(number);
        sc.close();
}
    //write logic to get inputs from user and send inputs to checkStrongNumber
    public void inputValidator(int number) {
    if (number < 0)
{
outputPrinter("Give proper input not negative number");
}
    else if (number == 0)
{
outputPrinter("Give proper input not zero");
}
    else
{
               boolean isStrong = checkStrongNumber(number);
outputPrinter("" + isStrong);
}
}
     //write logic to check Strong number or not and returns true if number is Strong otherwise false
    public boolean checkStrongNumber(int number)
{
int originalNumber = number;
          int sum = 0;
          while (number > 0)
{
              int digit = number % 10;
              sum += factorial(digit);
              number /= 10;
}
          return sum == originalNumber;
}
      private int factorial(int n)
{
          if (n == 0 || n==1)
{
              return 1;
}
          int fact = 1;
          for (int i = 1; i <= n; i++)
{
              fact *= i;
}
          return fact;
}
    //write logic to print the given printStatement
    public void outputPrinter(Object printStatement)
{
System.out.println(printStatement);
}
}