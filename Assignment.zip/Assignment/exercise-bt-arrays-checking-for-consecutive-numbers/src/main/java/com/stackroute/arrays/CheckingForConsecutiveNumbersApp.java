package com.stackroute.arrays;

import java.util.*;

public class CheckingForConsecutiveNumbersApp {
	public static void main(String[] args) {
		new CheckingForConsecutiveNumbersApp().readInput();
	}

	// write logic to get inputs from user and send inputs to inputValidator
	public void readInput() {
		Scanner s = new Scanner(System.in);
		String num = s.nextLine();
		inputValidator(num);
		s.close();
	}

	// write logic to send inputs to checkStrongNumber
	public void inputValidator(String input) {
		boolean res = checkForConsecutive(input);
		if (res == true) {
			displayResult("Given numbers are Consecutive");
		} else if (res == false) {
			displayResult("Given numbers are not Consecutive");
		}
	}

//write logic to check given numbers are consecutive or not and returns true if numbers are consecutive otherwise false
	public boolean checkForConsecutive(String input) {
		String[] numarr = input.split(",");
		int sortnum[] = new int[numarr.length];
		for (int i = 0; i < numarr.length; i++) {
			sortnum[i] = Integer.parseInt(numarr[i]);
		}
		Arrays.sort(sortnum);
		for (int i = 0; i < sortnum.length - 1; i++) {
			if (sortnum[i + 1] - sortnum[i] != 1) {
				return false;
			}
		}
		return true;
	}

//write logic to print the given printStatement
	public void displayResult(Object printStatement) {
		System.out.println(printStatement);
	}
}
