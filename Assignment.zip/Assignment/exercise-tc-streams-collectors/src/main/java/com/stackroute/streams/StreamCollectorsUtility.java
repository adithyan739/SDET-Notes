package com.stackroute.streams;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.util.Comparator.comparing;
import static java.util.Comparator.naturalOrder;

public class StreamCollectorsUtility {
    /**
     * This methods returns the list of odd squares of multiples of three for the given upper and lower limit.
     */
    public List<Integer> getOddSquaresOfMultiplesOfThree(int lowerLimit, int upperLimit) {
        return IntStream.rangeClosed(lowerLimit, upperLimit).boxed().
                filter(i -> i % 2 != 0 && i % 3 == 0)
                .map(i -> i * i).collect(Collectors.toList());
    }

    /**
     * This method returns the list of even multiples of five for the given the upper limit
     */

    public List<Integer> getEvenMultiplesOfFive(int upperLimit) {
        return IntStream.iterate(0, i -> i + 5).limit(upperLimit)
                .filter(i -> i % 2 == 0)
                .boxed().collect(Collectors.toList());
    }

    /**
     * This method returns the list of names in upper case after sorting the names by their length.
     * If lengths are same, names are sorted alphabetically.
     */

    public List<String> getSortedNameListInUppercase(List<String> names) {
        return names.stream().sorted(comparing(String::length).
                thenComparing(naturalOrder())).map(String::toUpperCase).collect(Collectors.toList());
    }
}
