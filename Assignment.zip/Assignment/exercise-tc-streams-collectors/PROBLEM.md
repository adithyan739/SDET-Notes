## Problem Statement: Writing unit test cases for the given solution ##

**This exercise should be completed by writing unit test cases for the solution provided**

- Below is the summary of the solution provided
    - class `StreamCollectorsUtility` contains methods using streams and collectors

- Create class `StreamCollectorsUtilityTests` in package `com.stackroute.streams`
     
      - should check for a list of integers of odd squares of multiples of three
      - should check for a list of integers of even multiples of five
      - should check for a list of names sorted by length in uppercase 
      - Minimum test cases expected : 12

- Each test case can have multiple assert checking.

- Test cases should be written for positive, negative and boundary scenarios, wherever applicable

- Test coverage should be 100%

## Instructions
- Avoid printing unnecessary values other than expected output as given in sample
- Take care of whitespace/trailing whitespace
- Do not change the provided class/method names unless instructed
- Follow best practices while coding
