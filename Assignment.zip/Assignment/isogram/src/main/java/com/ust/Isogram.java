package com.ust;

import java.util.Arrays;

/**
 * Hello world!
 *
 */
public class Isogram
{
	   /**
	 * Determines whether a given word is an isogram.
	 *
	 * @param  word the word to check for isogram status
	 * @return true if the word is an isogram, false otherwise
	 * @author Kirubakaran k
	 */
	public static boolean isIsogram(String word) {
		if(word==null) {
			throw new IllegalArgumentException();
		}
		word=word.replaceAll("-\\s", "").toLowerCase();
		for(int i=0;i<word.length();i++) {
			for(int j=i+1;j<word.length();j++)
				if(word.charAt(i)==word.charAt(j) ) {
				return false;
				}
				
		}return true;
	}
	
	 

	}
