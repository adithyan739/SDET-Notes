package Assessment.Assessment;

import java.util.Scanner;

public class GreaterName {
	public static String GetGreaterName(String str) {
		char[] ch = str.toCharArray();
		int n = ch.length;
		int i = n - 1;
		while (i > 0 && ch[i - 1] >= ch[i]) {
			i--;
		}
		if (i <= 0) {
			return "Not possible";
		}
		int j = n - 1;
		while (ch[j] <= ch[i - 1]) {
			j--;
		}
		char temp = ch[i - 1];
		ch[i - 1] = ch[j];
		ch[j] = temp;
		j = n - 1;
		while (i < j) {
			temp = ch[i];
			ch[i] = ch[j];
			ch[j] = temp;
			i++;
			j--;
		}
		return new String(ch);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		System.out.println(GetGreaterName(str));

	}

}
