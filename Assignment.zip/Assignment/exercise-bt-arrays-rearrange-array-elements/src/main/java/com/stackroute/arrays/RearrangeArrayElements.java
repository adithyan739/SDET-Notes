package com.stackroute.arrays;

import java.util.Scanner;

public class RearrangeArrayElements {
	public static void main(String[] args) {
		new RearrangeArrayElements().inputAcceptor();
	}

	// write logic to get inputs from user and send inputs for validation
	public void inputAcceptor() {
		// System.out.println("Enter size of array : ");
		Scanner scanner = new Scanner(System.in);
		int size = scanner.nextInt();
		if (!inputArraySizeValidator(size)) {
			displayResult(null);
		} else {
			// System.out.println("Enter array elements : ");
			int[] inputArray = new int[size];
			for (int index = 0; index < size; index++) {
				inputArray[index] = scanner.nextInt();
			}
			scanner.close();
			if (inputArrayValidator(inputArray)) {
				displayResult(computeRearrangedArray(inputArray));
			} else {
				displayResult(null);
			}
		}
	}

	// write logic to validate the given array size is valid or not
	public boolean inputArraySizeValidator(int size) {
		return size > 0;
	}

	// write logic to validate the given input array is sorted or not
	public boolean inputArrayValidator(int[] input) {
		// Array has one element
		if (input.length == 1)
			return true;
		for (int index = 1; index < input.length; index++)
			// Unsorted pair found
			if (input[index - 1] > input[index])
				return false;
		// No unsorted pair found
		return true;
	}

	// write logic to rearrange elements of array and return the result array
	public int[] computeRearrangedArray(int[] inputArray) {
		// check for given array is null or empty
		if (inputArray != null && inputArray.length > 0) {
			// temporary array to hold modified array
			int[] temp = new int[inputArray.length];
			// Indexes of smallest and largest elements
			// from remaining array.
			int small = 0;
			int large = inputArray.length - 1;
			// To indicate whether we need to copy remaining
			// largest or remaining smallest at next position
			boolean flag = true;
			// Store result in temp[]
			for (int index = 0; index < inputArray.length; index++) {
				if (flag)
					temp[index] = inputArray[large--];
				else
					temp[index] = inputArray[small++];
				flag = !flag;
			}
			return temp;
		} else
			return null;
	}

	// write logic to print the result
	public void displayResult(int[] outputArray) {
		if (outputArray == null) {
			System.out.println("Give proper input");
		} else {
			for (int index = 0; index < outputArray.length; index++)
				System.out.print(outputArray[index] + " ");
		}
	}
}