package com.ust;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import com.ust.Base.BrowserConfig;

public class BrowserDef {
	WebDriver driver;
	@Test
	public void getBrowser() {
		//to open browser
		driver=BrowserConfig.getBrowser();
		//if edge->webdriver d=new EdgeDriver();
		//to navigate to website
		driver.get("https://www.google.com");
		//to maximize the window
		driver.manage().window().maximize();
		//to navigate to website
		driver.navigate().to("https://www.mycontactform.com");
		//navigational methods
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();
		String title=driver.getTitle();
		String url=driver.getCurrentUrl();
		System.out.println(title);
		System.out.println(url);
		
	}
	
	
}
