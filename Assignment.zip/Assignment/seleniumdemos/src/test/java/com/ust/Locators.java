package com.ust;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.ust.Base.BrowserConfig;

public class Locators {
	WebDriver driver;
	@Test
	public void locators() {
		/*
		 * id 
		 * name
		 * linktext-->   <a></a>
		 * classname
		 * xpath
		 * cssSelector
		 */
		driver=BrowserConfig.getBrowser();
		driver.navigate().to("https://www.mycontactform.com");
		driver.manage().window().maximize();
		//driver.findElement(By.linkText("Sample Forms")).click();
		WebElement link=driver.findElement(By.linkText("Sample Forms"));
		link.click();
		driver.findElement(By.id("subject")).sendKeys("openheimer");
		driver.findElement(By.xpath("//input[@name='email_to[]'][@value='2']")).click();
		driver.findElement(By.id("attach4589")).sendKeys("C:\\Users\\k.kirubakaran\\Desktop\\Daywise plan --ust.xlsx");
		
	}
}
