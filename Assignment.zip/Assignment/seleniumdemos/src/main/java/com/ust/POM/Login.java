package com.ust.POM;

import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ust.Base.BaseUI;

public class Login extends BaseUI{
	WebDriver driver;
	public Login(WebDriver driver) {
		this.driver=driver;
	}
	//locators
	By username=getlocator("username_name");
	By password=getlocator("password_name");
	By submit=getlocator("submit_name");
	//elements as methods
	public void userName(String user) {
		sendtext(username, user);
	}
	public void passWord(String pass) {
		isElementPresent(password,Duration.ofSeconds(15));
		sendtext(password, pass);
	}
	public void submit() {
		WebElement submit_=driver.findElement(submit);
		submit_.click();
	}
			
}
