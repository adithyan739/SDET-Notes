package com.stackroute.strings;

import java.util.*;

public class Anagram {
	// write logic to check given two phrases are anagrams or not and return result
	public String checkAnagrams(String phraseOne, String phraseTwo) {
		if (phraseOne.isEmpty() || phraseTwo.isEmpty()) {
			return "Give proper input not empty phrases";
		}
		if (phraseOne.length() != phraseTwo.length()) {
			return "Given phrases are not anagrams";
		}
		char[] ch1 = phraseOne.toCharArray();
		char[] ch2 = phraseTwo.toCharArray();
		Arrays.sort(ch1);
		Arrays.sort(ch2);
		// Check if the sorted character arrays are equal
		if (Arrays.equals(ch1, ch2)) {
			return "Given phrases are anagrams";
		} else {
			return "Given phrases are not anagrams";
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s1 = sc.nextLine();
		String s2 = sc.nextLine();
		Anagram a = new Anagram();
		System.out.println(a.checkAnagrams(s1, s2));
	}
}
