package com.stackroute.exception;

public class Account {
	private int balance;

	public Account(int balance) {
		this.balance = balance;
	}

	public Account() {
		balance = 0;
	}

	public int getAccountBalance() {
		return balance;

	}

	public int withdraw(double amount) throws NegativeIntegerException, InsufficientFundException {
		if (amount < 0) {
			throw new NegativeIntegerException();
		}
		if (amount > balance) {
			throw new InsufficientFundException();
		}
		balance -= amount;
		return balance;
	}

	public class NegativeIntegerException extends Exception {
	}

	public class InsufficientFundException extends Exception {

	}

}
