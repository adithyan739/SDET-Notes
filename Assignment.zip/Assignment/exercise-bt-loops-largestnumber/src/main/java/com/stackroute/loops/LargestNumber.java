package com.stackroute.loops;

import java.util.Scanner;

public class LargestNumber {
	public static void main(String[] args) {
		new LargestNumber().inputAcceptor();
	}

	// write logic to get inputs from user and send inputs to inputValidator
	public void inputAcceptor() {
		Scanner sc = new Scanner(System.in);
		String inputND = sc.nextLine();
		inputValidator(inputND);
	}

	// write logic to validate inputs and send inputs to findLargestNumber
	public void inputValidator(String input) {
		String[] num = input.split("\\s");
		int N = Integer.parseInt(num[0]);
		int D = Integer.parseInt(num[1]);
		if (N < 0 || D < 0) {
			System.out.println("Give proper input not negative values");
		} else if (D >= 10) {
			System.out.println("Give proper input not digit greater than 9");
		} else if (N == 0) {
			System.out.println("Give proper input not number(N) equals to zero");
		} else {
			System.out.println(findLargestNumber(N, D));
		}
	}

	// write logic to find largest number and return it
	public int findLargestNumber(int number, int digit) {
		char c = Integer.toString(digit).charAt(0);
		for (int L = number; L > 0; --L) {
			if (Integer.toString(L).indexOf(c) == -1) {
				return L;
			}
		}
		return -1;
	}

	// write logic to print the given printStatement
	public void outputPrinter(Object printStatement) {
		System.out.println(printStatement);
	}
}