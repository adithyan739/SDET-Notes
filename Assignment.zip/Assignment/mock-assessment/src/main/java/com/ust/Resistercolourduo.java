package com.ust;

public class Resistercolourduo {
	    private static final String[] COLORS = {"black", "brown", "red", "orange", "yellow", "green", "blue", "violet", "grey", "white"};
	    /**
	     * Decodes a resistance value based on the input string and color codes.
	     *
	     * @param  input   the input string containing the resistance colors separated by hyphen
	     * @param  colors  an array of color codes used for decoding the resistance value
	     * @return         the decoded resistance value
	     */
	    
	    public static int decodeResistanceValue(String input, String[] colors) {

	    		if(input==null) {
	    			return 0;
	    			}
	    			if(input.isEmpty()) {
	    			return 0;
	    			}
	    			String[] str=input.split("-");

	    			if(str.length==1) {

	    			int index=getColorIndex(str[0],colors);

	    			return index;

	    			}
	    			String s="";

	    			for(int i=0;i<2;i++) {

	    			int index=getColorIndex(str[i],colors);
	    			s=s+index;
	    			}

	    			return Integer.parseInt(s);
	   
	    }
	    /**
	     * Returns the index of the given color in the specified array of colors.
	     *
	     * @param  color  the color whose index needs to be found
	     * @param  colors the array of colors in which to search for the color index
	     * @return        the index of the color in the array, or 0 if the color is not found
	     */
	    private static int getColorIndex(String color, String[] colors) {
	    	for(int i=0;i<colors.length;i++) {
	    		if(colors[i].equalsIgnoreCase(color)) {
	    			return i;
	    		}
	    	}return -1;
	       
	    }
	}

	

