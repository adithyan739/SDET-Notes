package com.stackroute.basics;

import java.util.Scanner;

public class SortAscNumber {

    public static void main(String[] args) {
        new SortAscNumber().getNumbers();
    }

    //get the numbers from user through console
    public void getNumbers() {
    	Scanner scanner=new Scanner(System.in);
    	   int firstNumber = scanner.nextInt();
           int secondNumber = scanner.nextInt();
           int thirdNumber = scanner.nextInt();
           int fourthNumber = scanner.nextInt();
           System.out.println(numberComparator(firstNumber, secondNumber, thirdNumber, fourthNumber));
           scanner.close();
       }

       // Logic to sort the numbers
       public String numberComparator(int firstNumber, int secondNumber, int thirdNumber, int fourthNumber) {
           int temp;

           // Sorting using if-else statements
       
           if (firstNumber > secondNumber) {
               temp = firstNumber;
               firstNumber = secondNumber;
               secondNumber = temp;
           }
           if (firstNumber > thirdNumber) {
               temp = firstNumber;
               firstNumber = thirdNumber;
               thirdNumber = temp;
           }
           if (firstNumber > fourthNumber) {
               temp = firstNumber;
               firstNumber = fourthNumber;
               fourthNumber = temp;
           }
           if (secondNumber > thirdNumber) {
               temp = secondNumber;
               secondNumber = thirdNumber;
               thirdNumber = temp;
           }
           if (secondNumber > fourthNumber) {
               temp = secondNumber;
               secondNumber = fourthNumber;
               fourthNumber = temp;
           }
           if (thirdNumber > fourthNumber) {
               temp = thirdNumber;
               thirdNumber = fourthNumber;
               fourthNumber = temp;
           }

           // Return the sorted numbers as a String
           return "Sorted numbers: " + firstNumber + ", " + secondNumber + ", " + thirdNumber + ", " + fourthNumber;
       }
   }