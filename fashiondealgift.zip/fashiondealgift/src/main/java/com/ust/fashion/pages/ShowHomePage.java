package com.ust.fashion.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ShowHomePage {
	WebDriver driver;
	
	@FindBy(xpath = "//span[text()='Gift Certificates']")
	private WebElement gift;

	public ShowHomePage(WebDriver driver) {
		this.driver = driver;
	}

	public GiftPurchasePage clickGiftPurchaselink() {
		gift.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Purchase a Gift Certificate"));
		return PageFactory.initElements(driver, GiftPurchasePage.class);
	}

}
