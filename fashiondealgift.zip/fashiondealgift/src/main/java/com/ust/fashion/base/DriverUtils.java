package com.ust.fashion.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DriverUtils {
	public static WebDriver driver;
	public static final String SERV_PROP_FILE = "develop.properties";
	public static Properties props;

	public DriverUtils(WebDriver driver) {
		this.driver = driver;
	}

	public static String getText(WebElement element) {
		String text = null;
		try {
			text = element.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}



	public static boolean isElementPresent(WebDriver driver, By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public static void delay(int seconds) {
		try {
			Thread.sleep(seconds);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	public static boolean isTextPresent(WebDriver driver, String Text) {
		try {
			return driver.findElement(By.tagName("body")).getText().contains(Text);
		} catch (NoSuchElementException e) {
			return false;
		}
	}

}
