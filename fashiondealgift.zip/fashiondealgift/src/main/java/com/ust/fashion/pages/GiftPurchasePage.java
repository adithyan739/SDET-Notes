package com.ust.fashion.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.fashion.base.DriverUtils;



public class GiftPurchasePage {
	private static WebDriver driver;

	WebDriverWait wait;

	public GiftPurchasePage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "input-to-name")
	private WebElement recpname;

	
	@FindBy(id="input-to-email")
	private WebElement recpemail;
	
	@FindBy(id = "input-from-name")
	private WebElement name;
	
	@FindBy(id = "input-from-email")
	private WebElement email;
	
	@FindBy(xpath="//input[@value='7']")
	private WebElement theme;
	
	@FindBy(xpath="//div[@class='pull-right']//input[@name='agree']")
	private WebElement agree;
	
	@FindBy(xpath="//div[@id='account-voucher']//div[@class='alert alert-danger alert-dismissible']")
	private WebElement errmsg;
	
	@FindBy(xpath="//button[@value='Continue']")
	private WebElement continue1;
	
	@FindBy(xpath="//a[@class='btn btn-primary']")
	private WebElement continue2;
	
	@FindBy(xpath="//button[@class='btn btn-danger']")
	private WebElement remove;
	
	@FindBy(xpath = "/html/body/div[4]/div/div/div/div/div/a")
	private WebElement continue3;
	
	@FindBy(xpath="//a[@class='btn btn-default']")
	private WebElement continueShop;
	
	
	public void inputRecpName(String rname) {
		recpname.sendKeys(rname);
	}
	
	public void inputRecpEmail(String remail) {
		recpemail.sendKeys(remail);
	}
	
	public void inputName(String iname) {
		name.sendKeys(iname);
	}
	
	public void inputEmail(String iemail) {
		email.sendKeys(iemail);
	}
	
	public void themeClick() {
		theme.click();
	}
	
	public void agreeClick() {
		agree.click();
	}
	
	public String errorMsgText() {
		return DriverUtils.getText(errmsg);
	}
	public void contClick() {
		continue1.click();
	}
	
	public void contClick1() {
		continue2.click();
	}
	
	public void removeClick() {
		remove.click();
	}
	
	public void contClick2() {
		continue3.click();
	}
	
	public String getBaseUrl() {
		return driver.getCurrentUrl();
    }
	
	 public  WebDriver returndriver() {
		 return driver;
	 }
	 

}
