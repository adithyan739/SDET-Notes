package com.ust.fashion.base;

import java.time.Duration;
import java.util.Properties;

import org.aeonbits.owner.ConfigCache;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ust.fashion.pages.ShowHomePage;
import com.ust.fashion.utils.FileIO;

public class BaseTest {
	public static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;

	public BaseTest() {
		prop = FileIO.initProperties();
	}

	@BeforeMethod
	public void setup() {
		browserChoice = prop.getProperty("browserName");
		if (browserChoice.equalsIgnoreCase("chrome")) {
			driver = BrowserConfig.getchromeBrowser();
		}
	}

	public ShowHomePage goToHomePage() {
		driver.get(prop.getProperty("Base_URL"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("The Online Fashion Store For Women's Ethnicwear Shopping"));
		Assert.assertEquals(driver.getTitle(), "The Online Fashion Store For Women's Ethnicwear Shopping");
		return PageFactory.initElements(driver, ShowHomePage.class);
	}
}
