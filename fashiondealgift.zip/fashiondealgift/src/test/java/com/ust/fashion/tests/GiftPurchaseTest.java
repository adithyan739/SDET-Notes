package com.ust.fashion.tests;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.ust.fashion.base.BaseTest;
import com.ust.fashion.base.DriverUtils;
import com.ust.fashion.pages.GiftPurchasePage;
import com.ust.fashion.pages.ShowHomePage;

public class GiftPurchaseTest extends BaseTest {
	public WebDriver driver;

	@Test(priority = 0)
	public void giftPurchaseTest() {
		ShowHomePage home = goToHomePage();
		GiftPurchasePage gift = home.clickGiftPurchaselink();
		String actualURL = gift.getBaseUrl();
		String expURL = "https://fashiondeal.in/index.php?route=account/voucher";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL.equalsIgnoreCase(expURL)).isTrue();
		});

		gift.inputRecpName("Adhi");
		gift.inputRecpEmail("adhi@gmail.com");
		gift.inputName("Shammi");
		gift.inputEmail("shammi@gmail.com");
		gift.themeClick();
		gift.agreeClick();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isElementPresent(gift.returndriver(), By.xpath("//button[@value='Continue']"))).isTrue();
		});
		gift.contClick();

		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					DriverUtils.isTextPresent(gift.returndriver(), "Thank you for purchasing a gift certificate! ")).isTrue();
		});
		gift.contClick1();

		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(gift.returndriver(), "₹1.00 Gift Certificate for Adhi")).isTrue();
		});
		gift.removeClick();
		DriverUtils.delay(2000);

		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(gift.returndriver(), "Your shopping cart is empty!")).isTrue();
		});
		gift.contClick2();

	}

	

	@Test(priority = 1)
	public void notclickAgree() {
		ShowHomePage home = goToHomePage();
		GiftPurchasePage gift = home.clickGiftPurchaselink();
		gift.inputRecpName("Adhi");
		gift.inputRecpEmail("adhi@gmail.com");
		gift.inputName("Shammi");
		gift.inputEmail("shammi@gmail.com");
		gift.themeClick();
		gift.contClick();
		String expected_text = "Warning: You must agree that the gift certificates are non-refundable!";
		String actual_text = gift.errorMsgText();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expected_text.equalsIgnoreCase(actual_text)).isTrue();
		});
	}

	@Test(priority=2)
	public void continueGiftPurchase() {
		ShowHomePage home=goToHomePage();
		GiftPurchasePage gift=home.clickGiftPurchaselink();
		gift.inputRecpName("");
		gift.inputRecpEmail("");
		gift.inputName("");
		gift.inputEmail("");
		gift.agreeClick();
		gift.contClick();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(gift.returndriver(), "Recipient's Name must be between 1 and 64 characters!")).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(gift.returndriver(), "E-Mail Address does not appear to be valid!")).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(gift.returndriver(), "Your Name must be between 1 and 64 characters!")).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(gift.returndriver(), "E-Mail Address does not appear to be valid!")).isTrue();
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(DriverUtils.isTextPresent(gift.returndriver(), "You must select a theme!")).isTrue();
		});
	}
}
