package testcases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.orange.base.BaseUI;
import com.orange.pages.OrangeHome;
import com.orange.pages.ShowHomePage;
import com.orange.utils.Excelutils;
import com.orange.utils.FileIO;









public class OrangehrmTest extends BaseUI{
	WebDriver driver;
	// DemoblazeSign demo;
	String[][] data;

	@DataProvider(name = "testData")
	public Object[][] testData() {
		data = Excelutils.testdata();
		return data;
	}

	@Test
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}
}
