package com.orange.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class ShowHomePage {
	private WebDriver driver;
	
	

	@FindBy(xpath = "//button[@type='submit']")
	private WebElement submit;
	
	@FindBy(xpath = "href=\"/web/index.php/admin/viewAdminModule\"")
	private WebElement admin;
	
	public ShowHomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public OrangeHome clickLoginButton() {
//		uname.sendKeys("Admin");
//		passwrd.sendKeys("admin123");
		submit.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("OrangeHRM"));
		return PageFactory.initElements(driver, OrangeHome.class);
	}

	
}
