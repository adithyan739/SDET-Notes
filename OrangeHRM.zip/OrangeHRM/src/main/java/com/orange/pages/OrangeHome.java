package com.orange.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OrangeHome {
	WebDriver driver;
	public OrangeHome(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(className = "oxd-input oxd-input--focus")
	WebElement uname;
	
	@FindBy(className = "oxd-input oxd-input--active")
	WebElement passwrd;
	
	
	public void inUsername() {
		uname.sendKeys("Admin");
	}
	public void inPassword() {
		passwrd.sendKeys("admin123");
	}
	
//	public OrangeHome nameEnter(String s) {
//		uname.sendKeys("Admin");
//		return this;
//	}
//	
//	public OrangeHome passEnter(String s) {
//		passwrd.sendKeys("admin123");
//		return this;
//	}
}
