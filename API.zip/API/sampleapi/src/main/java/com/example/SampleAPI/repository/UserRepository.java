package com.example.SampleAPI.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SampleAPI.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
}
