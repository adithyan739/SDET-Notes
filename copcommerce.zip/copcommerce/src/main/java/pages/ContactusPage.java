package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * This class represents a page object for the Contact Us page of a web application.
 */
public class ContactusPage {
	private WebDriver driver;
	WebDriverWait wait;
	 // Constant for the expected page title
	public static final String title = "nopCommerce demo store. Contact Us";
	
	/**
     * Constructor for the ContactUsPage class.
     *
     * @param driver The WebDriver instance to use for interacting with the page.
     */
	public ContactusPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		PageFactory.initElements(driver, this);
	}
	// WebElement declarations using @FindBy annotations
    // ...
	

	@FindBy(xpath = "//input[@id='FullName']")
	private WebElement name;
	@FindBy(xpath = "//input[@id='Email']")
	private WebElement email;
	@FindBy(xpath = "//textarea[@id='Enquiry']")
	private WebElement enquiry;
	@FindBy(xpath = "//button[@class='button-1 contact-us-button']")
	private WebElement sbm;
	@FindBy(xpath = "//div[@class='result']")
	private WebElement successmsg;
	
	@FindBy(xpath = "//span[@id='FullName-error']")
	private WebElement invname;
	@FindBy(xpath = "//span[@id='Email-error']")
	private WebElement invmail;
	@FindBy(xpath = "//span[@id='Enquiry-error']")
	private WebElement invenquiry;
	
	
	/**
     * Enter a name into the "Name" field.
     *
     * @param iname The name to be entered.
     */
	public void entername(String vname) {
		name.sendKeys(vname);
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	}
	
	/**
     * Enter an email into the "Email" field.
     *
     * @param iemail The email to be entered.
     */
	public void enteremail(String vemail) {
		email.sendKeys(vemail);
	}

	 /**
     * Enter a message into the message field.
     *
     * @param imsg The message to be entered.
     */
	public void enterenquiry(String venquiry) {
		enquiry.sendKeys(venquiry);
	}
	
	/**
     * Click the "Submit" button.
     */
	public void submit() {
		sbm.click();
	}
	
	/**
     * Get the current URL of the web page.
     *
     * @return The current URL.
     */
	public String getcurrentUrl() {
		return driver.getCurrentUrl();
	}
	
	/**
     * Get the WebDriver instance associated with this page.
     *
     * @return The WebDriver instance.
     */
	public WebDriver returnDriver() {
		return driver;
	}

	/**
     * Get the text of the alert message.
     *
     * @return The text of the alert message.
     */

	



	
}
