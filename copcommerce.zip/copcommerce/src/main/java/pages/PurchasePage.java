package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;




public class PurchasePage {
	private WebDriver driver;
	WebDriverWait wait;
	 /**
     * Constructor for the PurchaseProductPage class.
     *
     * @param driver The WebDriver instance to use for interacting with the page.
     */
	public PurchasePage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);
	}
	// WebElement declarations using @FindBy annotations
    // ...
	
	@FindBy(xpath = "//ul[@class='top-menu notmobile']//a[@href='/cell-phones']")
	private WebElement cellphones;
	@FindBy(xpath = "//select[@id='products-orderby']")
	private WebElement sortby;
	@FindBy(xpath = "//div[@class='picture']//img[@title='Show details for HTC One M8 Android L 5.0 Lollipop']")
	private WebElement selectproduct;
	@FindBy (xpath = "//button[@id='add-to-cart-button-18']")
	private WebElement addtocartbutton;
	@FindBy(xpath = "//div[@class='bar-notification success']")
	private WebElement cartpopup;
	@FindBy(xpath = "//div[@class='mini-shopping-cart']")
	private WebElement minicartview;
	@FindBy(xpath = "//span[@class='cart-label']")
	private WebElement viewcart;
	@FindBy(xpath = "//td[@class='sku']")
	private WebElement productcheck;
	@FindBy(xpath = "//select[@id='checkout_attribute_1']")
	private WebElement giftwrap;
	@FindBy(xpath = "//button[@id='updatecart']")
	private WebElement update;
	@FindBy(xpath = "//button[@name='continueshopping']")
	private WebElement continueshopping;
	
	 /**
     * Get the WebDriver instance associated with this page.
     *
     * @return The WebDriver instance.
     */
	public WebDriver driverreturn() {
		return driver;
	}
	/**
     * Get the current URL of the web page.
     *
     * @return The current URL.
     */
	public String actualURL() {
		return driver.getCurrentUrl();
	}
	// Methods for interacting with page elements
    // ...
	
	public void selectCellPhones() {
		cellphones.click();
	}
	
	public void sortbyPrize() {
		DriverUtils.dropDownHandling(sortby,"Price: Low to High");
	}
	public void clickProduct() {
		selectproduct.click();
	}
	/**
     * Click the "Add to Cart" button.
     */
	public void clickAddToCart() {
		addtocartbutton.click();
	}
	public void mouseoverOnCart() {
		DriverUtils.mouseOver(driverreturn(),minicartview);
	}
	public void clickViewCart(){
		viewcart.click();
	}
	public void selectGiftWrap() {
		DriverUtils.dropDownHandling(giftwrap, "Yes [+$10.00]");
		
	}
	public void clickUpdate(){
		update.click();
	}
	 /**
     * Click the "Continue Shopping" link.
     */
	public void clickContinueShopping(){
		continueshopping.click();
	}
	/**
     * Get the text of the product in the cart.
     *
     * @return The text of the product in the cart.
     */
	public String cartProductText() {
		return DriverUtils.getText(productcheck);
	}
	
}
