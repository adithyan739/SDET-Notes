package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


/**
 * This class represents a page object for the Show Home page of a web
 * application.
 */
public class ShowHomePage {
	private WebDriver driver;
	
//    // WebElement declarations using @FindBy annotations
//	@FindBy(xpath = "//a[@href='/register?returnUrl=%2F']")
//	WebElement reg;
	
	/**
     * Constructor for the ShowHomePage class.
     *
     * @param driver The WebDriver instance to use for interacting with the page.
     */
	public ShowHomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	 /**
     * Click the "Register" link and navigate to the User Registration page.
     *
     */
//	public UserRegistrationPage clickRegisterlink() {
//		reg.click();
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
//		wait.until(ExpectedConditions.titleIs("nopCommerce demo store. Register"));
//		return PageFactory.initElements(driver, UserRegistrationPage.class);
//	}
	
	
    // WebElement declarations using @FindBy annotations
	
	@FindBy(xpath = "//ul[@class='top-menu notmobile']//a[@href='/electronics']")
	private WebElement electronics;
	@FindBy(xpath= "//a[@href='/contactus']")
	private WebElement contact;

	
	/**
     * Click the "phone" link and navigate to the Purchase page.
     *
     * @return An instance of the PurchasePage class.
     */
	public PurchasePage clickElectronicslink() {
		electronics.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("nopCommerce demo store. Electronics"));
		return PageFactory.initElements(driver, PurchasePage.class);
	}
	

	
	/**
     * Click the "Contact Us" link and navigate to the Contact Us page.
     *
     * @return An instance of the ContactusPage class.
     */
	public ContactusPage clickContactuslink() {
		contact.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("nopCommerce demo store. Contact Us"));
		return PageFactory.initElements(driver, ContactusPage.class);
	}
	
	
}
