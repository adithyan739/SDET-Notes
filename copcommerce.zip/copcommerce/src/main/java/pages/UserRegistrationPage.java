package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


/**
 * This class represents a page object for the User Registration page of a web
 * application.
 */
public class UserRegistrationPage {
	// WebDriver and WebDriverWait for browser automation
	private WebDriver driver;
	WebDriverWait wait;

	// Constant for the expected page title
	public static final String title = "nopCommerce demo store. Register";

	/**
	 * Constructor for the UserRegistrationPage class.
	 *
	 * @param driver The WebDriver instance to use for interacting with the page.
	 */
	public UserRegistrationPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);
	}

	// WebElement declarations using @FindBy annotations
	@FindBy(xpath = "//a[@href='/register?returnUrl=%2F']")
	WebElement reg;
	
	@FindBy(id = "FirstName")
	WebElement FirstName;

	@FindBy(id = "LastName")
	WebElement LastName;

	@FindBy(id = "Email")
	WebElement Email1;

	@FindBy(id = "Password")
	WebElement Password1;

	@FindBy(id = "ConfirmPassword")
	WebElement ConfirmPassword;

	@FindBy(id = "register-button")
	WebElement register;

	// Methods for interacting with page elements
	// ...
	
	public String getTitle() {
		return driver.getTitle();
	}
	
	public void registerClick() {
		reg.click();;
	}
	
	public void firstName(String fname) {
		FirstName.sendKeys(fname);
	}

	public void lastName(String lname) {
		LastName.sendKeys(lname);
	}
	
	public void email1(String email) {
		Email1.sendKeys(email);
	}

	public void password1(String pwd) {
		Password1.sendKeys(pwd);
	}
	
public void confirmPas(String cpwd) {
	ConfirmPassword.sendKeys(cpwd);
}
	public void register() {
		register.click();;
	}

	public String getBaseUrl() {
		return driver.getCurrentUrl();
    }

	/**
	 * Get the WebDriver instance associated with this page.
	 *
	 * @return The WebDriver instance.
	 */
	public WebDriver driverreturn() {
		return driver;
	}

	/**
	 * Get the text of the success message element.
	 *
	 * @return The text of the success message.
	 */
//	public String successMsg() {
//		return DriverUtils.getText(successmsg);
//	}
}
