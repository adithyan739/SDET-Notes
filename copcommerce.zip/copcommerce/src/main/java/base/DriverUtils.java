package base;

import java.io.File;
import java.time.Duration;
import java.util.NoSuchElementException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import utilities.DateUtils;


/**
 * The DriverUtils class provides utility methods for interacting with WebDriver
 * instances. It includes methods for performing common actions like getting
 * text from elements, checking the presence of elements, handling dropdowns,
 * waiting, and more.
 */
public class DriverUtils extends BaseTest {
	public static WebDriver driver;

	/**
	 * Constructor for DriverUtils class that sets the WebDriver instance.
	 *
	 * @param driver The WebDriver instance to be used by utility methods.
	 */
	public DriverUtils(WebDriver driver) {
		this.driver = driver;
	}
	
	
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String timestamp = DateUtils.getTimeStamp();

	/**
	 * Gets the text of a WebElement.
	 *
	 * @param element The WebElement from which to retrieve text.
	 * @return The text of the WebElement, or null if an exception occurs.
	 */
	public static String getText(WebElement element) {
		String text = null;
		try {
			text = element.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	/**
	 * Gets the current URL of the WebDriver.
	 *
	 * @param element Not used in this method. (Method name appears to be a
	 *                misnomer)
	 */
	public static void getcurrenturl(WebElement element) {
		try {
			driver.getCurrentUrl();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Checks if an element is present within a specified timeout duration.
	 *
	 * @param locator The By locator of the element to check for presence.
	 * @param timeout The duration to wait for the element to be present.
	 * @return true if the element is present within the timeout, false otherwise.
	 */
	public static boolean isElementPresent(By locator, Duration timeout) {
		try {
			new WebDriverWait(driver, timeout).until(ExpectedConditions.presenceOfElementLocated(locator));
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Checks if a given text is present in the body of the page.
	 *
	 * @param driver The WebDriver instance.
	 * @param text   The text to check for.
	 * @return true if the text is present in the page's body, false otherwise.
	 */
	public static boolean isTextPresent(WebDriver driver, String Text) {
		try {
			return driver.findElement(By.tagName("body")).getText().contains(Text);
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/**
	 * Checks if an element is present.
	 *
	 * @param driver The WebDriver instance.
	 * @param by     The By locator of the element to check for presence.
	 * @return true if the element is present, false otherwise.
	 */
	public static boolean isElementPresent(WebDriver driver, By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/**
	 * Handles dropdowns by selecting an option with visible text.
	 *
	 * @param element The WebElement representing the dropdown.
	 * @param value   The visible text of the option to select.
	 */
	public static void dropDownHandling(WebElement element, String value) {
		try {
			Select s = new Select(element);
			s.selectByVisibleText(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Introduces a delay in the execution for the specified number of seconds.
	 *
	 * @param seconds The number of seconds to pause the execution.
	 */
	public static void delay(int seconds) {
		try {
			Thread.sleep(seconds);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Performs a mouse-over action on a WebElement.
	 *
	 * @param driver  The WebDriver instance.
	 * @param element The WebElement to perform the mouse-over action on.
	 */
	public static void mouseOver(WebDriver driver, WebElement element) {
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(element).build().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Closes an alert dialog and retrieves its text.
	 *
	 * @param driver          The WebDriver instance.
	 * @param acceptNextAlert If true, accepts the alert; if false, dismisses it.
	 * @return The text of the closed alert dialog.
	 */
	public static String closeAlertAndGetItsText(WebDriver driver, boolean acceptNextAlert) {
		Alert alert = driver.switchTo().alert();
		String alertText = alert.getText();
		if (acceptNextAlert) {
			alert.accept();
		} else {
			alert.dismiss();
		}
		return alertText;
	}
	
	public static String getTitle(WebDriver driver) {
		try {
			driver.getTitle();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return getTitle(driver);
	}
	
	/**************** screenshot *******************/
	public static void takescreenshot(WebDriver driver,String filePath) {
		try {
			File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(filePath));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
}
