package base;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import pages.ShowHomePage;
import utilities.FileIO;


/**
 * The BaseTest class serves as the base class for test classes in the test
 * automation framework. It initializes and manages the WebDriver instance and
 * provides common setup methods.
 */
public class BaseTest {
	static WebDriver driver;
	public static Properties SERV_PROP_FILE;
	public static String browserChoice;

	/**
	 * Constructor for BaseTest class that initializes properties and settings. It
	 * loads service properties using FileIO.
	 */
	public BaseTest() {
		SERV_PROP_FILE = FileIO.initProperties();
	}

	/**
	 * This method is annotated with @BeforeMethod, which means it will run
	 * before each test method. It is responsible for setting up a WebDriver
	 * instance based on the specified browser choice.
	 *
	 * @return A WebDriver instance configured for the chosen browser.
	 */
	@BeforeMethod
	public void setup() {
		browserChoice = SERV_PROP_FILE.getProperty("browserName");
		if (browserChoice.equalsIgnoreCase("Edge")) {
			driver = BrowserConfig.getedgebrowser();
			//driver.get(SERV_PROP_FILE.getProperty("Base_URL"));
		}
	}
	
	@AfterMethod
    public static void tearDownDriver() {
        driver.close();  // close the default window
        driver.quit();  // close the session
    }

	/**
	 * Navigates to the home page of the web application and performs necessary
	 * checks. It waits for the page title to match the expected title and asserts
	 * the title.
	 *
	 * @return An instance of the ShowHomePage class representing the home page.
	 */
	public ShowHomePage goToHomePage() {
		driver.get(SERV_PROP_FILE.getProperty("Base_Url"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("nopCommerce demo store"));
		Assert.assertEquals(driver.getTitle(), "nopCommerce demo store");
		return PageFactory.initElements(driver, ShowHomePage.class);
	}
	
	public static WebDriver getDriver() {
		return driver;
	}
	
}
