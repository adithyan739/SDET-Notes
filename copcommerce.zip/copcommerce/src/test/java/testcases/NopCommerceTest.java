package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;



import base.BaseTest;
import base.DriverUtils;
import pages.ContactusPage;
import pages.ShowHomePage;
import pages.UserRegistrationPage;
import utilities.Excelutils;
import utilities.FileIO;


//@Listeners(utilities.SampleListener.class)
public class NopCommerceTest extends BaseTest {
	WebDriver driver;
	String[][] data;
	
	public NopCommerceTest() {
		SERV_PROP_FILE = FileIO.initProperties();
	}
	@DataProvider(name = "testData")
	public Object[][] testdata() {
		data = Excelutils.testdata();
		return data;
	}
	// Method to perform register
//	@Test(priority = 1, dataProvider = "testdata")
	
		@Test(priority = 1,dataProvider ="testData")
		public void contactUs(String vname, String vemail, String venquiry) {
			ShowHomePage home = goToHomePage();
			ContactusPage contact = home.clickContactuslink();
			
			// Checking if contact us option is present
					SoftAssertions.assertSoftly(softAssertions -> {
						softAssertions.assertThat(DriverUtils.isElementPresent(contact.returnDriver(),
								By.xpath(SERV_PROP_FILE.getProperty("contactuslink")))).isTrue();
					});
					// Checking if its redirected to correct URL after clicking Contact Us
					String expurl = "https://demo.nopcommerce.com/contactus";
					String actualurl = contact.getcurrentUrl();
					SoftAssertions.assertSoftly(softAssertions -> {
						softAssertions.assertThat(expurl.equalsIgnoreCase(actualurl)).isTrue();
					});
					
					contact.entername(vname);
					contact.enteremail(vemail);
					contact.enterenquiry(venquiry);
					// Check if submit button is present on the page.
					SoftAssertions.assertSoftly(softAssertions -> {
						softAssertions.assertThat(DriverUtils.isElementPresent(contact.returnDriver(),
								By.xpath(SERV_PROP_FILE.getProperty("submitbutton")))).isTrue();
					});
					contact.submit();
					DriverUtils.delay(2000);
		
				
		}
		@Test(priority = 2)
		public void invalidContactUs() {
			ShowHomePage home = goToHomePage();
			ContactusPage contact = home.clickContactuslink();
			//Fill invalid data
			contact.submit();
			contact.entername("");
			contact.enteremail("");
			contact.enterenquiry("");
			
			
			// Assert error messages for each field.
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(
						DriverUtils.isTextPresent(contact.returnDriver(), "Enter your name"))
						.isTrue();
			});
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(
						DriverUtils.isTextPresent(contact.returnDriver(), "Enter email"))
						.isTrue();
			});
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(
						DriverUtils.isTextPresent(contact.returnDriver(), "Enter enquiry"))
						.isTrue();
			});
			
		}
		//public void register(String firstname, String lastname, String mail, String password, String confPass) {
//		ShowHomePage home = goToHomePage();
//		UserRegistrationPage user = home.clickRegisterlink();
//
//		// Assert URL, elements
//		String actualURL = user.getBaseUrl(); 
//		String expURL = "https://demo.nopcommerce.com/register?returnUrl=%2F";
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(actualURL.equalsIgnoreCase(expURL)).isTrue();
//
//		});
//
//		user.firstName(firstname);
//		user.lastName(lastname);
//		user.email1(mail);
//		user.password1(password);
//		user.confirmPas(confPass);
//		user.register();
//		
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(DriverUtils.isElementPresent(user.driverreturn(),
//					By.xpath(SERV_PROP_FILE.getProperty("continuebutton")))).isTrue();
//		});

	}

	// Method to perform login and assertions
//	@Test(priority = 2, dataProvider = "testdata1")
//	public void loginTest(String email, String password) {
//		String a = "https://demo.nopcommerce.com/";
//		driver.get(a);
//
//		NopCommerce log = new NopCommerce(driver);
//		log.login();
//		String actualURL = log.getURL();
//		String expURL = "https://demo.nopcommerce.com/login?returnUrl=%2F";
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(actualURL.equalsIgnoreCase(expURL)).isTrue();
//
//		});
//
//		log.email(email);
//		log.password(password);
//		log.submit();
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(a.contains("https://demo.nopcommerce.com/"));
//		});
//
//		String e = log.errorm();
//		if ((email.equals("IncorrectUser"))) {
//
//			SoftAssertions.assertSoftly(softAssertions -> {
//				softAssertions.assertThat(
//						e.equalsIgnoreCase("Login was unsuccessful. Please correct the errors and try again.\r\n"
//								+ "No customer account found"));
//			});
//		} else if (password.equals(" ")) {
//			SoftAssertions.assertSoftly(softAssertions -> {
//				softAssertions.assertThat(
//						e.equalsIgnoreCase("Login was unsuccessful. Please correct the errors and try again.\r\n"
//								+ "No customer account found"));
//			});
//		} else {
//
//			SoftAssertions.assertSoftly(softAssertions -> {
//				softAssertions.assertThat(a.contains("https://demo.nopcommerce.com/"));
//			});
//
//		}
//
//	}
//
//	// method to perform add a product to cart
//	@Test(priority = 3)
//	public void productSelect() {
//
//		NopCommerce log = new NopCommerce(driver);
//		log.electronics();
//		String actualURL = log.getURL();
//		String expURL = "https://demo.nopcommerce.com/electronics";
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(actualURL.equalsIgnoreCase(expURL));
//
//		});
//		
//		log.cameraphotoClick();
//		log.nikonClick();
//		log.cartClick();
//	}


